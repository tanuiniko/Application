package com.example.myapplication

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.PostAdapter
import com.example.myapplication.adapter.UserAdapter
import com.example.myapplication.data.Post
import com.example.myapplication.data.User
import com.example.myapplication.retrofit.ApiService
import com.example.myapplication.retrofit.RetrofitClient
import retrofit2.Callback
import retrofit2.Call
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var userRecyclerView : RecyclerView
    private lateinit var postRecyclerView: RecyclerView
    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity_layout)

        val retrofit = RetrofitClient.getClient("https://jsonplaceholder.typicode.com/")
        apiService = retrofit.create(ApiService::class.java)

        postRecyclerView = findViewById(R.id.posts_recycler_view)
        postRecyclerView.layoutManager = LinearLayoutManager(this)
        userRecyclerView = findViewById(R.id.users_recycler_view)
        userRecyclerView.layoutManager = LinearLayoutManager(this)

        getPosts()
        getUsers()

    }

    private fun getPosts(){
        val call = apiService.getPosts()
        call.enqueue(object : Callback<List<Post>>{
            override fun onResponse(call: Call<List<Post>>, response: Response<List<Post>>) {
                if(response.isSuccessful){
                    val posts=response.body()
                    Log.d("MainActivity","Posts: $posts")
                    posts?.let {
                        postRecyclerView.adapter=PostAdapter(it)
                    }
                }
            }

            override fun onFailure(call: Call<List<Post>>, t: Throwable) {
                Log.e("MainActivity", "Error fetching posts", t)
            }
        })
    }

    private fun getUsers() {
        val call = apiService.getUsers()
        call.enqueue(object : Callback<List<User>> {
            override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {
                if (response.isSuccessful) {
                    val users = response.body()
                    Log.d("MainActivity", "Users: $users")
                    users?.let {
                        userRecyclerView.adapter = UserAdapter(it)
                    }
                }
            }

            override fun onFailure(call: Call<List<User>>, t: Throwable) {
                Log.e("MainActivity", "Error fetching users", t)
            }
        })
    }
}