package com.example.myapplication.retrofit

import com.example.myapplication.data.Post
import com.example.myapplication.data.User
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("posts")
    fun getPosts(): Call<List<Post>>

    @GET("users")
    fun getUsers(): Call<List<User>>
}